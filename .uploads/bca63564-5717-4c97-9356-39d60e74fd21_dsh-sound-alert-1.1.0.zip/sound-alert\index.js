/** Host half of the sound-alert bundle; the chime itself is played by the Client module. */
export function apply() {}
