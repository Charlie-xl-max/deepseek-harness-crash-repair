![A bell with sound waves next to a green check mark, marking approval and completion chimes](preview.svg)
